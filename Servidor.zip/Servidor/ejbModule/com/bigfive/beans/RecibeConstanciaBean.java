package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class RecibeConstanciaBean
 */
@Stateless
public class RecibeConstanciaBean implements RecibeConstanciaBeanRemote {

    /**
     * Default constructor. 
     */
    public RecibeConstanciaBean() {
        // TODO Auto-generated constructor stub
    }

}
