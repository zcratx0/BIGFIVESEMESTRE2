package com.bigfive.beans;

import javax.ejb.Remote;

import com.bigfive.entities.Area;

@Remote
public interface AreaBeanRemoteRemote extends ICrud<Area>{

}
