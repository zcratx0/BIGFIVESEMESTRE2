package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class Responsabilidade
 */
@Stateless
public class Responsabilidade implements ResponsabilidadeRemote {

    /**
     * Default constructor. 
     */
    public Responsabilidade() {
        // TODO Auto-generated constructor stub
    }

}
