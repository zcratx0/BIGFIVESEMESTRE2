package com.bigfive.beans;
import javax.ejb.Remote;
import com.bigfive.entities.Accione;

@Remote
public interface AccionesBeanRemote extends ICrud<Accione>{

}
