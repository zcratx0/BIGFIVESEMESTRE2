package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class JustificacionBean
 */
@Stateless
public class JustificacionBean implements JustificacionBeanRemote {

    /**
     * Default constructor. 
     */
    public JustificacionBean() {
        // TODO Auto-generated constructor stub
    }

}
