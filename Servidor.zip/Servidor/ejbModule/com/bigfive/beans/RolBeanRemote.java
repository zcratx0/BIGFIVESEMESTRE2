package com.bigfive.beans;

import javax.ejb.Remote;

import com.bigfive.entities.Rol;

@Remote
public interface RolBeanRemote extends ICrud<Rol>{

}
