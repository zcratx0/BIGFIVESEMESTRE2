package com.bigfive.entities;

public enum EnumDepartamentos {
	ARTIGAS,
	CANELONES,
	CERRO_LARGO,
	COLONIA,
	DURAZNO,
	FLORES,
	FLORIDA,
	LAVALLEJA,
	MALDONADO,
	MONTEVIDEO,
	PAYSANDÚ,
	RÍO_NEGRO,
	RIVERA,
	ROCHA,
	SALTO,
	SAN_JOSÉ,
	SORIANO,
	TACUAREMBÓ,
	TREINTA_Y_TRES
}
