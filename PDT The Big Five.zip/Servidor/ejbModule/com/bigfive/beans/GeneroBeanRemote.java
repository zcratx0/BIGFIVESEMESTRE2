package com.bigfive.beans;

import javax.ejb.Remote;

import com.bigfive.entities.Genero;

@Remote
public interface GeneroBeanRemote extends ICrud<Genero>{

}
