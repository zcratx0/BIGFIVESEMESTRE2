package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class GestionBean
 */
@Stateless
public class GestionBean implements GestionBeanRemote {

    /**
     * Default constructor. 
     */
    public GestionBean() {
        // TODO Auto-generated constructor stub
    }

}
