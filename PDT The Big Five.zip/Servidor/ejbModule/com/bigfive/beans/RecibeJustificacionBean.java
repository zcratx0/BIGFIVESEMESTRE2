package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class RecibeJustificacionBean
 */
@Stateless
public class RecibeJustificacionBean implements RecibeJustificacionBeanRemote {

    /**
     * Default constructor. 
     */
    public RecibeJustificacionBean() {
        // TODO Auto-generated constructor stub
    }

}
