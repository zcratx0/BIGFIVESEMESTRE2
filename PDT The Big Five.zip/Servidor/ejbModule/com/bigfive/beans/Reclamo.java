package com.bigfive.beans;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class Reclamo
 */
@Stateless
public class Reclamo implements ReclamoRemote {

    /**
     * Default constructor. 
     */
    public Reclamo() {
        // TODO Auto-generated constructor stub
    }

}
