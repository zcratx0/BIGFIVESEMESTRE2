package com.bigfive.beans;

import javax.ejb.Remote;

import com.bigfive.entities.Analista;

@Remote
public interface AnalistaBeanRemoteRemote  extends ICrud<Analista> {

}
