package com.bigfive.beans;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class TipoBean
 */
@Stateless
@LocalBean
public class TipoBean implements TipoBeanRemote {

    /**
     * Default constructor. 
     */
    public TipoBean() {
        // TODO Auto-generated constructor stub
    }

}
