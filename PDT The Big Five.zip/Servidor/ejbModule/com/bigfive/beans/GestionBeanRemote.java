package com.bigfive.beans;

import javax.ejb.Remote;

@Remote
public interface GestionBeanRemote {

}
