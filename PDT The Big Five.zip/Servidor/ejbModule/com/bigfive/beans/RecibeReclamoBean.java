package com.bigfive.beans;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class RecibeReclamoBean
 */
@Stateless
@LocalBean
public class RecibeReclamoBean {

    /**
     * Default constructor. 
     */
    public RecibeReclamoBean() {
        // TODO Auto-generated constructor stub
    }

}
